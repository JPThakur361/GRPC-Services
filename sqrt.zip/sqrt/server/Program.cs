﻿using Grpc.Core;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Remoting.Channels;
using System.Threading.Tasks;

namespace server
{
    class Program
    {
        const int Port = 50052;

        static async Task Main(string [] main)
        {
            Server server = null;
            try
            {
                server = new Server()
                {
                    Ports = { new ServerPort("localhost", Port, ServerCredentials.Insecure) }
                };
                server.Start();
                Console.WriteLine("The server is listining is on Port No : ", Port);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine( "The server failed to start : "+e.Message);
                throw;
            }
            finally
            {
                if (server != null)
                    server.ShutdownAsync().Wait();
            }
        }
    }
}
